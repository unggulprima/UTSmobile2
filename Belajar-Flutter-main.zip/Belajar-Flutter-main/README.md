# Belajar-Flutter
## Profil
| Variable | Isi |
| -------- | --- |
| **Nama** | Gilar Sumilar |
| **NIM** | 312210407 |
| **Kelas** | TI.22.A4 |
| **Mata Kuliah** | Pemrograman Mobile |

https://github.com/GilarSumilar/Belajar-Flutter/assets/115634466/b9469f6f-cd52-4f71-a871-e3cc362ffe4b
